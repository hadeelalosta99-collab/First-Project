 // الفئة الأولى: مسؤولة عن ضبط حجم مشغل الصوت حسب حجم الشاشة
class Player {
  constructor() {
    // الحصول على العنصر الرئيسي الذي يحتوي على المشغل
    var HeightMain = document.getElementById("Player");

    // جعل ارتفاع العنصر مساوي لارتفاع الشاشة بالكامل
    HeightMain.style.height = screen.height + "px";

    // إذا كان عرض الشاشة أقل من 500px (أي شاشة هاتف)،
    // يتم ضبط عرض العنصر ليكون مساويًا لعرض الشاشة
    if (screen.width < 500) {
      HeightMain.style.width = screen.width + "px";
    }

    // الحصول على عنصر المحتوى الداخلي
    var HeightDiv = document.getElementById("content");

    // تقليل ارتفاع المحتوى الداخلي بمقدار 300px من ارتفاع الشاشة
    // لإتاحة مساحة للهيدر أو الأزرار
    HeightDiv.style.height = screen.height - 300 + "px";
  }
}

// إنشاء كائن جديد من فئة Player عند تحميل الصفحة
onload = new Player();


// الفئة الثانية: مسؤولة عن تشغيل الملفات الصوتية والتنقل بينها
class Audio_Player {
  constructor() {
    // الحصول على عناصر HTML المرتبطة بالمشغل
    this.AudioFile = document.getElementById("audiofile"); // عنصر الصوت
    this.TitleAudio = document.getElementById("titleaudio"); // اسم السورة
    this.PlayPauseButton = document.getElementById("playpause"); // زر التشغيل/الإيقاف
    this.IsPlayed = false; // حالة الصوت (مشغل أو متوقف)

    // أسماء السور التي ستظهر كعناوين للمقاطع
    this.names_radio = [
      "1 سورة الإخلاص",
      "3 سورة الفلق", 
      "2 سورة الناس"
    ];

    // المسارات الصوتية الخاصة بكل سورة
    this.Sourc_Audio = [
      "aleklass.mp3",
      "alfalak.mp3",
      "alnas.mp3"
    ];

    // متغير لتتبع أي ملف صوتي يتم تشغيله حاليًا
    this.server = 0;

    // استدعاء الدالة التي تضبط مصدر الصوت والعنوان
    this.SetResourc();

    // حدث عند الضغط على زر التشغيل/الإيقاف
    this.PlayPauseButton.addEventListener("click", () => {
      this.Play_Pause();
    });

    // حدث عند الضغط على زر "التالي"
    document.getElementById("next").addEventListener("click", () => {
      // الانتقال إلى المقطع التالي
      if (this.server < this.Sourc_Audio.length - 1) {
        ++this.server;
      } else {
        // إذا وصلنا للنهاية، نرجع لأول ملف
        this.server = 0;
      }

      // نغير الحالة إلى متوقف لتتم إعادة التشغيل
      this.IsPlayed = false;

      // حفظ موقع المقطع الحالي في localStorage
      localStorage.setItem("SAVE-POSITION", this.server);

      // تحديث الملف المعروض والمشغل
      this.SetResourc();
    });

    // حدث عند الضغط على زر "السابق"
    document.getElementById("back").addEventListener("click", () => {
      // الانتقال إلى المقطع السابق
      if (this.server > 0) {
        --this.server;
      } else {
        // إذا كنا في البداية نرجع لآخر مقطع
        this.server = this.Sourc_Audio.length - 1;
      }

      // نغير الحالة إلى متوقف
      this.IsPlayed = false;

      // حفظ موقع المقطع الحالي في localStorage
      localStorage.setItem("SAVE-POSITION", this.server);

      // تحديث الملف المعروض
      this.SetResourc();
    });
  }

  // دالة لتحديد مصدر الصوت والعنوان
  SetResourc() {
    // استرجاع آخر موضع تم حفظه (آخر سورة تم تشغيلها)
    if (localStorage.getItem("SAVE-POSITION") != null) {
      this.server = localStorage.getItem("SAVE-POSITION");
    }

    // تحديد الملف الصوتي الحالي حسب القيمة في this.server
    this.AudioFile.src = this.Sourc_Audio[this.server];

    // عرض اسم السورة في واجهة المشغل
    this.TitleAudio.innerHTML = this.names_radio[this.server];
  }

  // دالة التشغيل والإيقاف
  Play_Pause() {
    if (this.IsPlayed == false) {
      // إذا كان الصوت متوقف → نبدؤه بالتشغيل
      this.PlayPauseButton.src = "./img/pause.png"; // تغيير الأيقونة
      this.AudioFile.play(); // تشغيل الصوت
      this.IsPlayed = true;  // تحديث الحالة
    } else {
      // إذا كان الصوت مشغل → نوقفه
      this.PlayPauseButton.src = "./img/stop.png"; // تغيير الأيقونة
      this.AudioFile.pause(); // إيقاف الصوت
      this.IsPlayed = false;  // تحديث الحالة
    }
  }
}

// إنشاء كائن جديد من فئة Audio_Player عند تحميل الصفحة
onload = new Audio_Player();

