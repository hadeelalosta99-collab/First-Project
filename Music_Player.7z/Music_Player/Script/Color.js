 class Color {
    constructor() {
        // الحصول على الزر الأول (color1) من خلال الـ id
        this.Color1 = document.getElementById("color1");
        // إضافة حدث عند النقر لتغيير اللون إلى color1
        this.Color1.addEventListener("click", () => {
            this.Select_Color("color1");
        });

        // الحصول على الزر الثاني (color2)
        this.Color2 = document.getElementById("color2");
        // عند النقر يتم اختيار اللون الثاني
        this.Color2.addEventListener("click", () => {
            this.Select_Color("color2");
        });

        // الحصول على الزر الثالث (color3)
        this.Color3 = document.getElementById("color3");
        // عند النقر يتم اختيار اللون الثالث
        this.Color3.addEventListener("click", () => {
            this.Select_Color("color3");
        });

        // الحصول على الزر الرابع (color4)
        this.Color4 = document.getElementById("color4");
        // عند النقر يتم اختيار اللون الرابع
        this.Color4.addEventListener("click", () => {
            this.Select_Color("color4");
        });
 
        // إذا لم يكن هناك لون محفوظ مسبقاً في localStorage
        // يتم تعيين اللون الافتراضي للصفحة
        if (localStorage.getItem("COLOR") == null) {
            document.body.style.background = "rgb(162, 76, 242)";
        }

        // استرجاع اللون المحفوظ وتطبيقه عند تحميل الصفحة
        this.Select_Color(localStorage.getItem("COLOR"));
    }
    
    // دالة لتغيير لون الخلفية بناءً على الزر المختار
    Select_Color(color) {
        if (color == "color1") {
            document.body.style.background = "rgb(162, 76, 242)";
        }
        else if (color == "color2") {
            document.body.style.background = "rgb(114, 102, 126)";
        }
        else if (color == "color3") {
            document.body.style.background = "rgb(210, 136, 205)";
        }
        else if (color == "color4") {
            document.body.style.background = "rgb(37, 24, 36)";
        }

        // تخزين اللون المختار في localStorage ليبقى محفوظاً عند إعادة تحميل الصفحة
        localStorage.setItem("COLOR", color);
    }
}

// إنشاء كائن من الفئة Color عند تحميل الصفحة
onload = new Color();
