 class Volume {
  constructor() {
    // الحصول على عنصر الصوت (ملف الصوت) من خلال الـ id
    this.AudioFile = document.getElementById("audiofile");
    
    // تعيين القيم الابتدائية عند تحميل الصفحة
    // مستوى الصوت يكون 50%
    this.AudioFile.volume = 0.5;
    // سرعة التشغيل تكون عادية (1 تعني السرعة الأصلية)
    this.AudioFile.playbackRate = 1;

    // الحصول على شريط التحكم في مستوى الصوت
    this.VolumeRange = document.getElementById("volume_range");
    // عند تغيير قيمة شريط الصوت يتم تحديث مستوى الصوت في ملف الصوت
    this.VolumeRange.addEventListener("change", () => {
      // القيمة من 0 إلى 100 لذا نقسمها على 100 لتصبح بين 0 و 1
      this.AudioFile.volume = this.VolumeRange.value / 100;
    });

    // الحصول على شريط التحكم في سرعة التشغيل
    this.VolumeSpeed = document.getElementById("volume_speed");
    // عند تغيير القيمة يتم تعديل سرعة تشغيل الصوت
    this.VolumeSpeed.addEventListener("change", () => {
      // القيمة من 0 إلى 100 لذا نقسمها على 100 لتصبح مناسبة لمعامل السرعة
      this.AudioFile.playbackRate = this.VolumeSpeed.value / 100;
    });
  }
}

// إنشاء كائن جديد من الفئة Volume عند تحميل الصفحة
onload = new Volume();

